var dir_e76e844777b8919c382e03460066671c =
[
    [ "MadMela.h", "MadMela_8h.html", "MadMela_8h" ],
    [ "Mela.h", "Mela_8h.html", [
      [ "Mela", "classMela.html", "classMela" ]
    ] ],
    [ "MELAAccumulators.h", "MELAAccumulators_8h.html", "MELAAccumulators_8h" ],
    [ "MELACandidate.h", "MELACandidate_8h.html", [
      [ "MELACandidate", "classMELACandidate.html", "classMELACandidate" ]
    ] ],
    [ "MELACombinePdfs.h", "MELACombinePdfs_8h.html", [
      [ "MELAqqZZPdf_v2", "classMELAqqZZPdf__v2.html", "classMELAqqZZPdf__v2" ],
      [ "MELAggZZPdf_v2", "classMELAggZZPdf__v2.html", "classMELAggZZPdf__v2" ],
      [ "MELADoubleCB", "classMELADoubleCB.html", "classMELADoubleCB" ],
      [ "MELARelBWUFParam", "classMELARelBWUFParam.html", "classMELARelBWUFParam" ]
    ] ],
    [ "MELADifermionResolutionModel.h", "MELADifermionResolutionModel_8h.html", [
      [ "MELADifermionResolutionModel", "classMELADifermionResolutionModel.html", "classMELADifermionResolutionModel" ]
    ] ],
    [ "MELAFuncPdf.h", "MELAFuncPdf_8h.html", [
      [ "MELAFuncPdf", "classMELAFuncPdf.html", "classMELAFuncPdf" ]
    ] ],
    [ "MELAHXSWidth.h", "MELAHXSWidth_8h.html", [
      [ "MELAHXSWidth", "classMELAHXSWidth.html", "classMELAHXSWidth" ]
    ] ],
    [ "MelaIO.h", "MelaIO_8h.html", [
      [ "MelaIO", "classMelaIO.html", "classMelaIO" ]
    ] ],
    [ "MELALinearInterpFunc.h", "MELALinearInterpFunc_8h.html", [
      [ "MELALinearInterpFunc", "classMELALinearInterpFunc.html", "classMELALinearInterpFunc" ]
    ] ],
    [ "MELANCSpline_1D_fast.h", "MELANCSpline__1D__fast_8h.html", [
      [ "MELANCSpline_1D_fast", "classMELANCSpline__1D__fast.html", "classMELANCSpline__1D__fast" ]
    ] ],
    [ "MELANCSpline_2D_fast.h", "MELANCSpline__2D__fast_8h.html", [
      [ "MELANCSpline_2D_fast", "classMELANCSpline__2D__fast.html", "classMELANCSpline__2D__fast" ]
    ] ],
    [ "MELANCSpline_3D_fast.h", "MELANCSpline__3D__fast_8h.html", [
      [ "MELANCSpline_3D_fast", "classMELANCSpline__3D__fast.html", "classMELANCSpline__3D__fast" ]
    ] ],
    [ "MELANCSplineCore.h", "MELANCSplineCore_8h.html", [
      [ "MELANCSplineCore", "classMELANCSplineCore.html", "classMELANCSplineCore" ]
    ] ],
    [ "MELANCSplineFactory_1D.h", "MELANCSplineFactory__1D_8h.html", [
      [ "MELANCSplineFactory_1D", "classMELANCSplineFactory__1D.html", "classMELANCSplineFactory__1D" ]
    ] ],
    [ "MELANCSplineFactory_2D.h", "MELANCSplineFactory__2D_8h.html", "MELANCSplineFactory__2D_8h" ],
    [ "MELANCSplineFactory_3D.h", "MELANCSplineFactory__3D_8h.html", "MELANCSplineFactory__3D_8h" ],
    [ "MELAOutputStreamer.h", "MELAOutputStreamer_8h.html", "MELAOutputStreamer_8h" ],
    [ "MELAParticle.h", "MELAParticle_8h.html", "MELAParticle_8h" ],
    [ "MelaPConstant.h", "MelaPConstant_8h.html", [
      [ "MelaPConstant", "classMelaPConstant.html", "classMelaPConstant" ]
    ] ],
    [ "MELAStreamHelpers.hh", "MELAStreamHelpers_8hh.html", "MELAStreamHelpers_8hh" ],
    [ "MELAThreeBodyDecayCandidate.h", "MELAThreeBodyDecayCandidate_8h.html", "MELAThreeBodyDecayCandidate_8h" ],
    [ "PDGHelpers.h", "PDGHelpers_8h.html", "PDGHelpers_8h" ],
    [ "PseudoMELA.h", "PseudoMELA_8h.html", [
      [ "PseudoMELA", "classPseudoMELA.html", "classPseudoMELA" ]
    ] ],
    [ "RooqqZZ_JHU.h", "RooqqZZ__JHU_8h.html", [
      [ "RooqqZZ_JHU", "classRooqqZZ__JHU.html", "classRooqqZZ__JHU" ]
    ] ],
    [ "RooqqZZ_JHU_ZgammaZZ_fast.h", "RooqqZZ__JHU__ZgammaZZ__fast_8h.html", [
      [ "RooqqZZ_JHU_ZgammaZZ_fast", "classRooqqZZ__JHU__ZgammaZZ__fast.html", "classRooqqZZ__JHU__ZgammaZZ__fast" ]
    ] ],
    [ "RooRapidityBkg.h", "RooRapidityBkg_8h.html", [
      [ "RooRapidityBkg", "classRooRapidityBkg.html", "classRooRapidityBkg" ]
    ] ],
    [ "RooRapiditySig.h", "RooRapiditySig_8h.html", [
      [ "RooRapiditySig", "classRooRapiditySig.html", "classRooRapiditySig" ]
    ] ],
    [ "RooSpin.h", "RooSpin_8h.html", "RooSpin_8h" ],
    [ "RooSpinOne_7D.h", "RooSpinOne__7D_8h.html", [
      [ "RooSpinOne_7D", "classRooSpinOne__7D.html", "classRooSpinOne__7D" ]
    ] ],
    [ "RooSpinTwo.h", "RooSpinTwo_8h.html", [
      [ "RooSpinTwo", "classRooSpinTwo.html", "classRooSpinTwo" ],
      [ "modelCouplings", "structRooSpinTwo_1_1modelCouplings.html", "structRooSpinTwo_1_1modelCouplings" ]
    ] ],
    [ "RooSpinTwo_7DComplex_ppHVV.h", "RooSpinTwo__7DComplex__ppHVV_8h.html", [
      [ "RooSpinTwo_7DComplex_ppHVV", "classRooSpinTwo__7DComplex__ppHVV.html", "classRooSpinTwo__7DComplex__ppHVV" ]
    ] ],
    [ "RooSpinZero.h", "RooSpinZero_8h.html", [
      [ "RooSpinZero", "classRooSpinZero.html", "classRooSpinZero" ],
      [ "modelCouplings", "structRooSpinZero_1_1modelCouplings.html", "structRooSpinZero_1_1modelCouplings" ]
    ] ],
    [ "RooSpinZero_3D_pp_VH.h", "RooSpinZero__3D__pp__VH_8h.html", [
      [ "RooSpinZero_3D_pp_VH", "classRooSpinZero__3D__pp__VH.html", "classRooSpinZero__3D__pp__VH" ]
    ] ],
    [ "RooSpinZero_5D_VH.h", "RooSpinZero__5D__VH_8h.html", [
      [ "RooSpinZero_5D_VH", "classRooSpinZero__5D__VH.html", "classRooSpinZero__5D__VH" ]
    ] ],
    [ "RooSpinZero_7DComplex_withAccep_HVV.h", "RooSpinZero__7DComplex__withAccep__HVV_8h.html", [
      [ "RooSpinZero_7DComplex_withAccep_HVV", "classRooSpinZero__7DComplex__withAccep__HVV.html", "classRooSpinZero__7DComplex__withAccep__HVV" ],
      [ "accepParameters", "structRooSpinZero__7DComplex__withAccep__HVV_1_1accepParameters.html", "structRooSpinZero__7DComplex__withAccep__HVV_1_1accepParameters" ]
    ] ],
    [ "RooTsallis.h", "RooTsallis_8h.html", [
      [ "RooTsallisSM", "classRooTsallisSM.html", "classRooTsallisSM" ]
    ] ],
    [ "RooTsallisExp.h", "RooTsallisExp_8h.html", [
      [ "RooTsallisExp", "classRooTsallisExp.html", "classRooTsallisExp" ]
    ] ],
    [ "ScalarPdfFactory.h", "ScalarPdfFactory_8h.html", [
      [ "ScalarPdfFactory", "classScalarPdfFactory.html", "classScalarPdfFactory" ]
    ] ],
    [ "ScalarPdfFactory_HVV.h", "ScalarPdfFactory__HVV_8h.html", [
      [ "ScalarPdfFactory_HVV", "classScalarPdfFactory__HVV.html", "classScalarPdfFactory__HVV" ]
    ] ],
    [ "ScalarPdfFactory_VH.h", "ScalarPdfFactory__VH_8h.html", [
      [ "ScalarPdfFactory_VH", "classScalarPdfFactory__VH.html", "classScalarPdfFactory__VH" ]
    ] ],
    [ "SpinPdfFactory.h", "SpinPdfFactory_8h.html", [
      [ "SpinPdfFactory", "classSpinPdfFactory.html", "classSpinPdfFactory" ]
    ] ],
    [ "SuperDijetMela.h", "SuperDijetMela_8h.html", [
      [ "SuperDijetMela", "classSuperDijetMela.html", "classSuperDijetMela" ]
    ] ],
    [ "SuperMELA.h", "SuperMELA_8h.html", [
      [ "SuperMELA", "classSuperMELA.html", "classSuperMELA" ]
    ] ],
    [ "TCouplings.hh", "TCouplings_8hh.html", [
      [ "SpinZeroCouplings", "classSpinZeroCouplings.html", "classSpinZeroCouplings" ],
      [ "SpinOneCouplings", "classSpinOneCouplings.html", "classSpinOneCouplings" ],
      [ "SpinTwoCouplings", "classSpinTwoCouplings.html", "classSpinTwoCouplings" ],
      [ "VprimeCouplings", "classVprimeCouplings.html", "classVprimeCouplings" ],
      [ "aTQGCCouplings", "classaTQGCCouplings.html", "classaTQGCCouplings" ],
      [ "AZffCouplings", "classAZffCouplings.html", "classAZffCouplings" ]
    ] ],
    [ "TCouplingsBase.hh", "TCouplingsBase_8hh.html", "TCouplingsBase_8hh" ],
    [ "TensorPdfFactory.h", "TensorPdfFactory_8h.html", [
      [ "TensorPdfFactory", "classTensorPdfFactory.html", "classTensorPdfFactory" ]
    ] ],
    [ "TensorPdfFactory_ppHVV.h", "TensorPdfFactory__ppHVV_8h.html", [
      [ "TensorPdfFactory_ppHVV", "classTensorPdfFactory__ppHVV.html", "classTensorPdfFactory__ppHVV" ]
    ] ],
    [ "TEvtProb.hh", "TEvtProb_8hh.html", [
      [ "TEvtProb", "classTEvtProb.html", "classTEvtProb" ]
    ] ],
    [ "TJHUGenUtils.hh", "TJHUGenUtils_8hh.html", "TJHUGenUtils_8hh" ],
    [ "TMCFM.hh", "TMCFM_8hh.html", "TMCFM_8hh" ],
    [ "TMCFMUtils.hh", "TMCFMUtils_8hh.html", "TMCFMUtils_8hh" ],
    [ "TModGravitonMatEl.hh", "TModGravitonMatEl_8hh.html", "TModGravitonMatEl_8hh" ],
    [ "TModHashCollection.hh", "TModHashCollection_8hh.html", "TModHashCollection_8hh" ],
    [ "TModHiggsJJMatEl.hh", "TModHiggsJJMatEl_8hh.html", "TModHiggsJJMatEl_8hh" ],
    [ "TModHiggsJMatEl.hh", "TModHiggsJMatEl_8hh.html", "TModHiggsJMatEl_8hh" ],
    [ "TModHiggsMatEl.hh", "TModHiggsMatEl_8hh.html", "TModHiggsMatEl_8hh" ],
    [ "TModJHUGen.hh", "TModJHUGen_8hh.html", "TModJHUGen_8hh" ],
    [ "TModJHUGenMELA.hh", "TModJHUGenMELA_8hh.html", "TModJHUGenMELA_8hh" ],
    [ "TModKinematics.hh", "TModKinematics_8hh.html", "TModKinematics_8hh" ],
    [ "TModParameters.hh", "TModParameters_8hh.html", "TModParameters_8hh" ],
    [ "TModTTBHMatEl.hh", "TModTTBHMatEl_8hh.html", "TModTTBHMatEl_8hh" ],
    [ "TModVHiggsMatEl.hh", "TModVHiggsMatEl_8hh.html", "TModVHiggsMatEl_8hh" ],
    [ "TModZprimeMatEl.hh", "TModZprimeMatEl_8hh.html", "TModZprimeMatEl_8hh" ],
    [ "TNNPDFDriver.hh", "TNNPDFDriver_8hh.html", "TNNPDFDriver_8hh" ],
    [ "TNumericUtil.hh", "TNumericUtil_8hh.html", "TNumericUtil_8hh" ],
    [ "TUtil.hh", "TUtil_8hh.html", "TUtil_8hh" ],
    [ "TUtilHelpers.hh", "TUtilHelpers_8hh.html", "TUtilHelpers_8hh" ],
    [ "TVar.hh", "TVar_8hh.html", "TVar_8hh" ],
    [ "VectorPdfFactory.h", "VectorPdfFactory_8h.html", [
      [ "VectorPdfFactory", "classVectorPdfFactory.html", "classVectorPdfFactory" ]
    ] ],
    [ "ZZMatrixElement.h", "ZZMatrixElement_8h.html", [
      [ "ZZMatrixElement", "classZZMatrixElement.html", "classZZMatrixElement" ]
    ] ]
];