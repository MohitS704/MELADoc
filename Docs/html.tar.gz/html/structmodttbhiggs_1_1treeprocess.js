var structmodttbhiggs_1_1treeprocess =
[
    [ "boson", "structmodttbhiggs_1_1treeprocess.html#aaba39d4f002a58874be6b1e8bf493e4f", null ],
    [ "bosonvertex", "structmodttbhiggs_1_1treeprocess.html#aa24da70f89ab4a9a06ae6c46f4a4bda8", null ],
    [ "gluons", "structmodttbhiggs_1_1treeprocess.html#a5e1175bc6ceff83470a920aafa8c77b6", null ],
    [ "numglu", "structmodttbhiggs_1_1treeprocess.html#a6b171909353a0464d111e8687d0f3978", null ],
    [ "numpart", "structmodttbhiggs_1_1treeprocess.html#a2df2354692fd2101cb7be07662d71882", null ],
    [ "numqua", "structmodttbhiggs_1_1treeprocess.html#a4f7a0b5b390a63d689f65186adacfdd8", null ],
    [ "numsca", "structmodttbhiggs_1_1treeprocess.html#a966f72eb94bc7813ce21d3da30157572", null ],
    [ "numv", "structmodttbhiggs_1_1treeprocess.html#a5e6996eee4ca92fb46728e5d50b66568", null ],
    [ "numw", "structmodttbhiggs_1_1treeprocess.html#ad0a474b22650a8ad3b032c566985bd29", null ],
    [ "partref", "structmodttbhiggs_1_1treeprocess.html#ae610e393a46577fb409e8e1ace3bfd0e", null ],
    [ "parttype", "structmodttbhiggs_1_1treeprocess.html#af5d03dc5c8bd6bc4867ffb7fdf25a262", null ],
    [ "quarks", "structmodttbhiggs_1_1treeprocess.html#a4646569e5922218d06ed847f86e351a0", null ],
    [ "scalars", "structmodttbhiggs_1_1treeprocess.html#a88b0842596e158bb7d9a695986a1fb70", null ]
];