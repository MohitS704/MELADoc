var classAZffCouplings =
[
    [ "AZffCouplings", "classAZffCouplings.html#a0280695ff1b67cf5d044b14f29982ed3", null ],
    [ "AZffCouplings", "classAZffCouplings.html#a597edbb1044efca75095e1d779051109", null ],
    [ "~AZffCouplings", "classAZffCouplings.html#a80cafef18e9e1722badbef2d96515795", null ],
    [ "copy", "classAZffCouplings.html#abac2a1cdde8c27413fbfd9cd27128a1f", null ],
    [ "getRef", "classAZffCouplings.html#a984134cddcda174a8fa9599c453b0d98", null ],
    [ "reset", "classAZffCouplings.html#a90872cef827cc5b4273c1b9cf69abfb3", null ],
    [ "SetAZffCouplings", "classAZffCouplings.html#abfc66f05812bb2e16eed4125a9fc3940", null ],
    [ "AZffcoupl", "classAZffCouplings.html#aa964188c2116027c391aa525fdd6418c", null ]
];