var classaTQGCCouplings =
[
    [ "aTQGCCouplings", "classaTQGCCouplings.html#a6f68c526a73f7551d6f25c3f74d85acb", null ],
    [ "aTQGCCouplings", "classaTQGCCouplings.html#a16e83cd2650f46a75c2793a32744e054", null ],
    [ "~aTQGCCouplings", "classaTQGCCouplings.html#a02fa26c68dc622976e4d70bea0d86ca1", null ],
    [ "copy", "classaTQGCCouplings.html#a76732f1c53766e007d47f38be7a8f1f6", null ],
    [ "getRef", "classaTQGCCouplings.html#a6cea5eb8b1386da4a8eb638c985761e8", null ],
    [ "reset", "classaTQGCCouplings.html#ae7930d9d576ea1b093c9c3d7ccd042b5", null ],
    [ "SetATQGCCouplings", "classaTQGCCouplings.html#abbca97b9862ab83c164c5c75ba5f0c16", null ],
    [ "aTQGCcoupl", "classaTQGCCouplings.html#ab90473f8613a7b3240bf8d9e67a18dfa", null ]
];