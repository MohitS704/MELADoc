var classVprimeCouplings =
[
    [ "VprimeCouplings", "classVprimeCouplings.html#abfa263a4fc13e8152080fe55a58d6211", null ],
    [ "VprimeCouplings", "classVprimeCouplings.html#acc7d7f68f1139fc1d056bc7b62e2158c", null ],
    [ "~VprimeCouplings", "classVprimeCouplings.html#a5398e063544d26bb228d01344fcd6628", null ],
    [ "copy", "classVprimeCouplings.html#aa992cae384e9324cd81dbbe6e24e334e", null ],
    [ "getRef", "classVprimeCouplings.html#a446cd084c60905514b85cc1abbdd8864", null ],
    [ "reset", "classVprimeCouplings.html#a58970704ced33fd0617fb3c2e6c0cd61", null ],
    [ "SetVpffCouplings", "classVprimeCouplings.html#a70a1313122fb9d4ba6116a68a8083d17", null ],
    [ "SetWPrimeMassWidth", "classVprimeCouplings.html#a8fab5e83a87a240ba58e9bcc31fef259", null ],
    [ "SetZPrimeMassWidth", "classVprimeCouplings.html#a3b39dd2ca83c7ef8dc683d7f6e037606", null ],
    [ "Ga_Wprime", "classVprimeCouplings.html#a8b9a6156e7f58470f2850bf7effe1c15", null ],
    [ "Ga_Zprime", "classVprimeCouplings.html#a01c16ccd200a3bdabda6c9e4af2c250b", null ],
    [ "M_Wprime", "classVprimeCouplings.html#a9843878dff809a3189bc0c0e49d6d807", null ],
    [ "M_Zprime", "classVprimeCouplings.html#a95df53cef1f6548f6e47daebc3016d3f", null ],
    [ "Wpffcoupl", "classVprimeCouplings.html#a5736fa2d9f4fc9cc7ffc7104b5df7df9", null ],
    [ "Zpffcoupl", "classVprimeCouplings.html#a40e3fa0b1c5983da374a6a594d004c1b", null ]
];