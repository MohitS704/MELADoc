var structmodttbhiggs_1_1ptrtoparticle =
[
    [ "extref", "structmodttbhiggs_1_1ptrtoparticle.html#a23b53a936a6ffdb2fe761b2f86dc6a01", null ],
    [ "helicity", "structmodttbhiggs_1_1ptrtoparticle.html#a85e415690e570f9a60800a59f1e86978", null ],
    [ "mass", "structmodttbhiggs_1_1ptrtoparticle.html#a590826002538009db68a356662b9e6fe", null ],
    [ "mass2", "structmodttbhiggs_1_1ptrtoparticle.html#ab7f834aa536f65c3cfc5ebc04da1e377", null ],
    [ "mom", "structmodttbhiggs_1_1ptrtoparticle.html#a49c79e5de798117f6171715fa6bcc819", null ],
    [ "parttype", "structmodttbhiggs_1_1ptrtoparticle.html#aa10175d799ea41121975a8a8f740ac10", null ],
    [ "pol", "structmodttbhiggs_1_1ptrtoparticle.html#a1ee0cde63ea39b9296987bc4e6ad441c", null ]
];