var namespacecollier__init =
[
    [ "setmaxcheck_cll", "interfacecollier__init_1_1setmaxcheck__cll.html", "interfacecollier__init_1_1setmaxcheck__cll" ],
    [ "setmaxcritpoints_cll", "interfacecollier__init_1_1setmaxcritpoints__cll.html", "interfacecollier__init_1_1setmaxcritpoints__cll" ]
];