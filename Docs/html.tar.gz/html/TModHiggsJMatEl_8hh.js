var TModHiggsJMatEl_8hh =
[
    [ "__modhiggsj_MOD_evalamp_hj", "TModHiggsJMatEl_8hh.html#af791d297390be936ae83e21a176c34dd", null ]
];