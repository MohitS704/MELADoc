var dir_97dcdc0483a27cbec027b7b62fbb001f =
[
    [ "checkparams_coli.h", "checkparams__coli_8h.html", "checkparams__coli_8h" ],
    [ "coli_aux2.F90", "coli__aux2_8F90.html", "coli__aux2_8F90" ],
    [ "coli_stat.F90", "coli__stat_8F90.html", "coli__stat_8F90" ],
    [ "common_coli.h", "common__coli_8h.html", "common__coli_8h" ],
    [ "global_coli.h", "global__coli_8h.html", "global__coli_8h" ],
    [ "interfaceAD.F90", "interfaceAD_8F90.html", "interfaceAD_8F90" ],
    [ "params_coli.h", "params__coli_8h.html", "params__coli_8h" ],
    [ "reductionAB.F90", "reductionAB_8F90.html", "reductionAB_8F90" ],
    [ "reductionC.F90", "reductionC_8F90.html", "reductionC_8F90" ],
    [ "reductionD.F90", "reductionD_8F90.html", "reductionD_8F90" ],
    [ "reductionEFG.F90", "reductionEFG_8F90.html", "reductionEFG_8F90" ],
    [ "reductionTN.F90", "reductionTN_8F90.html", "reductionTN_8F90" ]
];