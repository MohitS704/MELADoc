var interfacemodttbhiggs_1_1operator_07_8ndot_8_08 =
[
    [ "fourvecdot", "interfacemodttbhiggs_1_1operator_07_8ndot_8_08.html#a4602c3e39999d4d9e2131c4f26bf3eab", null ]
];