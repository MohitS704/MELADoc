var classRooTsallisSM =
[
    [ "RooTsallisSM", "classRooTsallisSM.html#a82e0f75acdaf231a00285d343689013c", null ],
    [ "RooTsallisSM", "classRooTsallisSM.html#a558cf662104cc360556816a616f0c823", null ],
    [ "~RooTsallisSM", "classRooTsallisSM.html#a4a8afea01c8891973ff818592b033e63", null ],
    [ "clone", "classRooTsallisSM.html#a6092fdbd3e7706874d41cc1de26ead3b", null ],
    [ "evaluate", "classRooTsallisSM.html#a482caba0f3c08f6ada36ece6a4174e95", null ],
    [ "bb0", "classRooTsallisSM.html#ac2b9395aa96d7ae10f5a9dd04402af76", null ],
    [ "bb1", "classRooTsallisSM.html#a10c93214768bf1ec0ea6f8f55cb0efb3", null ],
    [ "bb2", "classRooTsallisSM.html#acd49cc34252a706c47a67a1d0ef254e6", null ],
    [ "m", "classRooTsallisSM.html#a8f7c8c8335382084055de1b39ac87d8c", null ],
    [ "mzz", "classRooTsallisSM.html#ab32656866a41ccfbe519e29bed50258e", null ],
    [ "n0", "classRooTsallisSM.html#a24052457db7a3dda19f89bdff6acb3ac", null ],
    [ "n1", "classRooTsallisSM.html#ae1bf3a89b352d860fd5fb119bf1cd24c", null ],
    [ "n2", "classRooTsallisSM.html#a0f6f7a970f0762510cac1f9d3c0de572", null ],
    [ "ndue", "classRooTsallisSM.html#a0d511706793bc7c816ea8188ae66a188", null ],
    [ "T0", "classRooTsallisSM.html#a1b74f773347d5f5d098e62ee742c8742", null ],
    [ "T1", "classRooTsallisSM.html#a4b04ad159021d15d0d16ea2cb09f8786", null ],
    [ "T2", "classRooTsallisSM.html#a5029239cb424f7e2221b5f0f7f1eed34", null ],
    [ "x", "classRooTsallisSM.html#ad4441553428cd44f7185812ef0422c13", null ]
];