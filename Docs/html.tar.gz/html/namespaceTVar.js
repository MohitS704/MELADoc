var namespaceTVar =
[
    [ "event_scales_type", "structTVar_1_1event__scales__type.html", "structTVar_1_1event__scales__type" ],
    [ "simple_event_record", "structTVar_1_1simple__event__record.html", "structTVar_1_1simple__event__record" ]
];