var classMELADoubleCB =
[
    [ "MELADoubleCB", "classMELADoubleCB.html#a9484c4b3e4e91711ab179a7209bbfd72", null ],
    [ "MELADoubleCB", "classMELADoubleCB.html#a73accffb05c9f1b93246c3ce6bde4279", null ],
    [ "MELADoubleCB", "classMELADoubleCB.html#a42c2fe6739963e7d7ab1abf8ade8d5b3", null ],
    [ "~MELADoubleCB", "classMELADoubleCB.html#a9406a0120d7528516062d681ffac165c", null ],
    [ "analyticalIntegral", "classMELADoubleCB.html#ac74b16aff7000ffd2a021b9419008ace", null ],
    [ "clone", "classMELADoubleCB.html#a537a12582ccebd2bd08ef5b073331755", null ],
    [ "evaluate", "classMELADoubleCB.html#ac63828cd3b0a5bfd428181ecc858cd25", null ],
    [ "getAnalyticalIntegral", "classMELADoubleCB.html#aa09ae03b8e78db69917b359936c7b0b2", null ],
    [ "alpha1", "classMELADoubleCB.html#a6dd04ced632f528db2b0bb5c461d80fa", null ],
    [ "alpha2", "classMELADoubleCB.html#a8517ce47d4a2f3da4a0a3135da6bc62e", null ],
    [ "mean", "classMELADoubleCB.html#a2586d45035272d2bcb90a510754b26d3", null ],
    [ "n1", "classMELADoubleCB.html#a72f1427879fa38cb739cf386498f1356", null ],
    [ "n2", "classMELADoubleCB.html#a8c684e9c9ebc1bb9692573f7492c594e", null ],
    [ "width", "classMELADoubleCB.html#a71de26b1bab0e7d02e6eda2dc767cc7e", null ],
    [ "x", "classMELADoubleCB.html#a9c30045e45f79a6c151a0821b831f21b", null ]
];