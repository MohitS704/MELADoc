var MELANCSplineFactory__2D_8h =
[
    [ "MELANCSplineFactory_2D", "classMELANCSplineFactory__2D.html", "classMELANCSplineFactory__2D" ],
    [ "splineTriplet_t", "MELANCSplineFactory__2D_8h.html#a19b716f6c590bf6b550622e87e0517c0", null ]
];