var coli__stat_8F90 =
[
    [ "initstatisticsa_coli", "coli__stat_8F90.html#af94b20befcbbd513cef8ac7ff89164be", null ],
    [ "printstatistics_coli", "coli__stat_8F90.html#ae327f6f45f71c51be78f300c9844ec3a", null ],
    [ "ccount", "coli__stat_8F90.html#a9bb28bcb383d088519980da8c97e4287", null ],
    [ "ccountoffset0", "coli__stat_8F90.html#a8eaea7da4fedf01a262994f08942e660", null ],
    [ "ccountoffset1", "coli__stat_8F90.html#a839d18c235a7fe2ce791214cb72174d4", null ],
    [ "ccountoffset2", "coli__stat_8F90.html#a9c776b250cf540cd25c22e7e9c317564", null ],
    [ "ccountoffset3", "coli__stat_8F90.html#a6b9006b9ada064ebbb787e60ab771782", null ],
    [ "dcount", "coli__stat_8F90.html#a7de44beed234ff3117530863305e7051", null ],
    [ "dcountoffset0", "coli__stat_8F90.html#ad9aa88586e884f2107b6939382e08a71", null ],
    [ "dcountoffset1", "coli__stat_8F90.html#a60865ccc867e2395c826580326fe127c", null ],
    [ "dcountoffset2", "coli__stat_8F90.html#ad64a2967102b06a084d3083c020eec26", null ],
    [ "dcountoffset3", "coli__stat_8F90.html#a5c8f08395d70ae305da313411794d602", null ],
    [ "kcountc", "coli__stat_8F90.html#ab317c28316a02efbeb37e2a0ec904bbb", null ],
    [ "kcountd", "coli__stat_8F90.html#a4c9d6e90282ef68e001b3d3a54d36908", null ],
    [ "ncountc", "coli__stat_8F90.html#a27433c0508515080100be9a69ade468f", null ],
    [ "ncountd", "coli__stat_8F90.html#abe4b95f0e31a9d103515e2174113c6ff", null ],
    [ "nmethodc", "coli__stat_8F90.html#a0b5fa73f70f03aa78e149f50fc1f43ed", null ],
    [ "nmethodd", "coli__stat_8F90.html#a77f53e727c82a7a9c16fa6f6e3a5302e", null ]
];