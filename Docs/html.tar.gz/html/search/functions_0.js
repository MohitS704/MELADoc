var searchData=
[
  ['_21_20copyright_5616',['! Copyright',['../checkparams__coli_8h.html#a876617252dd3614ba0d944110794eac1',1,'! Copyright(C) 2015:&#160;checkparams_coli.h'],['../common__coli_8h.html#abaa3f02236f79eee49bcbf4e77a48d1c',1,'! Copyright(C) 2015:&#160;common_coli.h'],['../global__coli_8h.html#a93f3f8d3c774fac50b56f2097f406101',1,'! Copyright(C) 2015:&#160;global_coli.h'],['../params__coli_8h.html#a4ce67c15853030043ac6116ef861a425',1,'! Copyright(C) 2015:&#160;params_coli.h']]]
];
