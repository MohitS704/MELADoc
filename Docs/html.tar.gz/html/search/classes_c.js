var searchData=
[
  ['quadruplet_5293',['quadruplet',['../structTNumericUtil_1_1quadruplet.html',1,'TNumericUtil']]]
];
