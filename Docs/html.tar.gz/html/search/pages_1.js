var searchData=
[
  ['event_5fscales_5ftype_8558',['event_scales_type',['../event_scales_type.html',1,'PyMela_page']]]
];
