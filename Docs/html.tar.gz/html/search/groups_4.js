var searchData=
[
  ['python_20functions_20that_20are_20pass_2dby_2dreference_20in_20c_2b_2b_8556',['Python Functions that are pass-by-reference in C++',['../group__ReferenceGroup.html',1,'']]]
];
