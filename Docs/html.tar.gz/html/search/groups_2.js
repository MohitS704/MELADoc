var searchData=
[
  ['functions_20that_20construct_20objects_20differently_20than_20the_20c_2b_2b_8554',['Functions that construct objects differently than the C++',['../group__Constructors.html',1,'']]]
];
