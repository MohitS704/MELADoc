var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz~",
  1: "abekmnopqrstvz",
  2: "adhmpt",
  3: "cdelmnprstvz",
  4: "_abcdefghijklmnopqrstuvwxyz~",
  5: "_abcdefghijklmnopqrstuvwxyz",
  6: "dfimpstu",
  7: "bceflmprsv",
  8: "abcdefghijklmnprstz",
  9: "_bcgmqsx",
  10: "cdfnp",
  11: "ceimpst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros",
  10: "Modules",
  11: "Pages"
};

