var searchData=
[
  ['xstr_5flit_8551',['xstr_lit',['../TVar_8hh.html#a70eecd39bee9bdde6a1c379e7f56b64e',1,'TVar.hh']]]
];
