var searchData=
[
  ['coupling_20definition_20macros_10525',['Coupling definition Macros',['../group__Macros.html',1,'']]]
];
