var searchData=
[
  ['couplings_20table_8557',['Couplings Table',['../MELA_couplings_table.html',1,'MELA_python']]]
];
