var searchData=
[
  ['defined_20coupling_20quantities_8553',['Defined Coupling Quantities',['../group__coupl.html',1,'']]]
];
