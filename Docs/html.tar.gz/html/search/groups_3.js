var searchData=
[
  ['novel_20python_20functions_8555',['Novel Python Functions',['../group__Pychanges.html',1,'']]]
];
