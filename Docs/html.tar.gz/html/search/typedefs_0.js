var searchData=
[
  ['defaultaccumulator_8052',['DefaultAccumulator',['../namespaceTNumericUtil.html#ac1e15acb346327d63f8cba17d50a4fda',1,'TNumericUtil']]],
  ['doublequad_5ft_8053',['doubleQuad_t',['../namespaceTNumericUtil.html#a0cc4d4977150149589a84735b7b7094b',1,'TNumericUtil']]],
  ['doubletriplet_5ft_8054',['doubleTriplet_t',['../namespaceTNumericUtil.html#abee54a00beb23472ba3d09ee18bab1d6',1,'TNumericUtil']]]
];
