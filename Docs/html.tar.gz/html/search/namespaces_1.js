var searchData=
[
  ['debugvars_4324',['debugVars',['../namespacedebugVars.html',1,'']]]
];
