var interfacecollier__tensors_1_1aten__cll =
[
    [ "aten_args_cll", "interfacecollier__tensors_1_1aten__cll.html#adf2706424212d014c7d566a99eb9b2db", null ],
    [ "aten_args_list_cll", "interfacecollier__tensors_1_1aten__cll.html#a317aea661b79e6e01a027d7f38c4698d", null ],
    [ "aten_list_cll", "interfacecollier__tensors_1_1aten__cll.html#af51dabc3f890e30f112d6222eb5516ca", null ],
    [ "aten_main_cll", "interfacecollier__tensors_1_1aten__cll.html#a777665252aca040a6a38f9cc911232d6", null ]
];