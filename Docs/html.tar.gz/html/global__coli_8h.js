var global__coli_8h =
[
    [ "! Copyright", "global__coli_8h.html#a93f3f8d3c774fac50b56f2097f406101", null ],
    [ "Denner", "global__coli_8h.html#a59d95fc2a7fa073ab9cf285844588f69", null ],
    [ "Dittmaier", "global__coli_8h.html#a6e1aaaeb37573a8543a3335ebab10e25", null ],
    [ "version", "global__coli_8h.html#ac3d3b1955f3f3dc67375d97bc15dca00", null ]
];