var structRooSpin_1_1modelParameters =
[
    [ "gamW", "structRooSpin_1_1modelParameters.html#ab205f52435d1570bcc51cfb9664555b2", null ],
    [ "gamWprime", "structRooSpin_1_1modelParameters.html#a922f2dcd46b623cb2d198e82200922f2", null ],
    [ "gamX", "structRooSpin_1_1modelParameters.html#a37338f0fff538e02a9190d723c563720", null ],
    [ "gamZ", "structRooSpin_1_1modelParameters.html#af5fd514b83d5a24507dc3359bc434d7f", null ],
    [ "gamZprime", "structRooSpin_1_1modelParameters.html#aa06a75407686e0fd3d2afa433486e32e", null ],
    [ "gVprimeff_decay1_left", "structRooSpin_1_1modelParameters.html#a3ec1d33c7a142217f05bf864d5467c23", null ],
    [ "gVprimeff_decay1_right", "structRooSpin_1_1modelParameters.html#a6dfdb1e1a8d80fb35cf7a35919291f0b", null ],
    [ "gVprimeff_decay2_left", "structRooSpin_1_1modelParameters.html#a711179257930736e8d99360a1c3b1251", null ],
    [ "gVprimeff_decay2_right", "structRooSpin_1_1modelParameters.html#a585f17f844d893b80e887f8f425e2a60", null ],
    [ "mW", "structRooSpin_1_1modelParameters.html#a1bb8d915ef2d8973ea90f032a848e19f", null ],
    [ "mWprime", "structRooSpin_1_1modelParameters.html#aa606d7f2b0938e9f1efc34b93a8e7122", null ],
    [ "mX", "structRooSpin_1_1modelParameters.html#a0b7d3d0ae8f424efee3c614422b801eb", null ],
    [ "mZ", "structRooSpin_1_1modelParameters.html#a1d9c867e9e3ef5627013ef1300205e96", null ],
    [ "mZprime", "structRooSpin_1_1modelParameters.html#a46119b8c646820a047003b86d89fc8c0", null ],
    [ "Sin2ThetaW", "structRooSpin_1_1modelParameters.html#a1a3992ec2ea1de40e4f2f9578c19b062", null ],
    [ "vev", "structRooSpin_1_1modelParameters.html#a91f75de98c0689009c7dabdd8bfab38b", null ]
];