var classMELARelBWUFParam =
[
    [ "MELARelBWUFParam", "classMELARelBWUFParam.html#a5300feaabfef2555f7daa6372834a6d0", null ],
    [ "MELARelBWUFParam", "classMELARelBWUFParam.html#a01acb2d238baa8cd03c40909e80f0fe4", null ],
    [ "MELARelBWUFParam", "classMELARelBWUFParam.html#a4d98fcd110f212aa2384ee508c113d9c", null ],
    [ "~MELARelBWUFParam", "classMELARelBWUFParam.html#af88d6e8d409ecca36d3e5e97e6a0d522", null ],
    [ "clone", "classMELARelBWUFParam.html#af98d09863db34e6b0e52b5a7e61d6e3d", null ],
    [ "evaluate", "classMELARelBWUFParam.html#aac23eadcae7aec0fe82f7edcd18053c9", null ],
    [ "m4l", "classMELARelBWUFParam.html#a19acdeae4482465413b8f70a644579b2", null ],
    [ "mH", "classMELARelBWUFParam.html#ad6a8ebd011ad209d59b1d4f08dfccb14", null ],
    [ "scaleParam", "classMELARelBWUFParam.html#a291300e7922c8258fec7ccb06377755a", null ],
    [ "widthSF", "classMELARelBWUFParam.html#a304dd5a49da4790261c59b46ff849df3", null ]
];