var reductionAB_8F90 =
[
    [ "calca", "reductionAB_8F90.html#a830e147b967aa323197f252813d31b46", null ],
    [ "calcb", "reductionAB_8F90.html#a40a6a12d427c2629c9b244714c2d6568", null ],
    [ "calcbred", "reductionAB_8F90.html#ab2c1956e06c8f4d33fc193daa4d65acf", null ],
    [ "calcdb", "reductionAB_8F90.html#a1fc936c5cff25bbe805906c28d3063c2", null ]
];