var interfacecollier__coefs_1_1b0__cll =
[
    [ "b0_arrays_cll", "interfacecollier__coefs_1_1b0__cll.html#a3c8a460638c48276fad518c35590436a", null ],
    [ "b0_main_cll", "interfacecollier__coefs_1_1b0__cll.html#acfafdaea12c571b4f0963ddab365cd6b", null ]
];