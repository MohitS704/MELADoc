var py_enums =
[
    [ "TVar Enumerations", "tvar_enums.html", [
      [ "Verbosity Level", "tvar_enums.html#verbosity_enum", null ],
      [ "Matrix Element", "tvar_enums.html#matel_enum", null ],
      [ "Production", "tvar_enums.html#prod_enum", null ],
      [ "Process", "tvar_enums.html#proc_enum", null ],
      [ "Resonance Propagator Scheme", "tvar_enums.html#reso_enum", null ],
      [ "EventScaleScheme", "tvar_enums.html#scale_enum", null ],
      [ "CandidateDecayMode", "tvar_enums.html#decmode_enum", null ]
    ] ],
    [ "TCouplingsBase Enums", "tcoupling_enums.html", [
      [ "autotoc_md11", "tcoupling_enums.html#autotoc_md11", null ]
    ] ]
];