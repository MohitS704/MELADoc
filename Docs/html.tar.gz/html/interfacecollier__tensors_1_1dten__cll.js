var interfacecollier__tensors_1_1dten__cll =
[
    [ "dten_args_cll", "interfacecollier__tensors_1_1dten__cll.html#adc9d8de66850806e1b2d732943c44d0f", null ],
    [ "dten_args_list_cll", "interfacecollier__tensors_1_1dten__cll.html#a2c316249c09565f936e77e7f52e607fd", null ],
    [ "dten_list_cll", "interfacecollier__tensors_1_1dten__cll.html#ab737ffad366974a4d77ec94c1fa1691b", null ],
    [ "dten_main_cll", "interfacecollier__tensors_1_1dten__cll.html#acbafe9c02e786f03496a0f5834b108b8", null ]
];